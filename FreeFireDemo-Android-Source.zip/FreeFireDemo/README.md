# Painel Flutuante Demo (Android)

Projeto Android Java que solicita permissão de sobreposição, exibe um painel flutuante arrastável e pode abrir Free Fire ou Free Fire MAX se estiver instalado. Os marcadores são sintéticos e servem apenas para demonstração visual; o app não lê memória do jogo, não revela jogadores reais e não automatiza a mira.

## Gerar APK
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle e a instalação do SDK solicitada.
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Usar
1. Instale e abra o APK.
2. Toque em **Ativar painel e abrir Free Fire**.
3. Na primeira execução, o Android abrirá a configuração de sobreposição. Autorize o app e volte para ele.
4. Toque novamente no botão. O painel aparece e o app tenta abrir Free Fire; se a versão normal não estiver instalada, tenta Free Fire MAX.
5. Arraste o painel pela barra superior. Use os botões para ocultar os marcadores fictícios ou fechar o painel.

A permissão de sobreposição não concede acesso aos dados internos de outros apps. O jogo precisa estar instalado oficialmente no dispositivo.
