package com.example.aimpanel;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private DemoView markers;
    private View panel;
    private boolean markersVisible = true;
    private WindowManager.LayoutParams markerParams;
    private WindowManager.LayoutParams panelParams;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        markers = new DemoView();
        markerParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        markerParams.gravity = Gravity.TOP | Gravity.START;

        panel = createPanel();
        panelParams = new WindowManager.LayoutParams(
            dp(220), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(18); panelParams.y = dp(100);
        panel.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY; private float touchX, touchY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = panelParams.x; startY = panelParams.y; touchX = e.getRawX(); touchY = e.getRawY(); return false;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    panelParams.x = startX + (int)(e.getRawX() - touchX);
                    panelParams.y = startY + (int)(e.getRawY() - touchY);
                    try { wm.updateViewLayout(panel, panelParams); } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });
        try { wm.addView(markers, markerParams); wm.addView(panel, panelParams); }
        catch (Exception ignored) { stopSelf(); }
    }

    private View createPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(10), dp(8), dp(10), dp(10));
        box.setBackgroundColor(Color.rgb(28, 32, 40));
        TextView title = new TextView(this); title.setText("PAINEL DEMO  ⋮ arraste");
        title.setTextColor(Color.WHITE); title.setTextSize(14); title.setPadding(dp(2), dp(4), dp(2), dp(8)); box.addView(title);
        Button toggle = new Button(this); toggle.setText("Ocultar marcadores demo"); box.addView(toggle);
        toggle.setOnClickListener(v -> {
            markersVisible = !markersVisible;
            markers.setVisibility(markersVisible ? View.VISIBLE : View.INVISIBLE);
            toggle.setText(markersVisible ? "Ocultar marcadores demo" : "Mostrar marcadores demo");
        });
        Button close = new Button(this); close.setText("Fechar painel"); box.addView(close);
        close.setOnClickListener(v -> stopSelf());
        return box;
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public int onStartCommand(Intent i, int flags, int startId) { return START_NOT_STICKY; }
    @Override public void onDestroy() {
        if (wm != null) {
            if (markers != null) try { wm.removeView(markers); } catch (Exception ignored) {}
            if (panel != null) try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }

    private class DemoView extends View {
        private final Paint p = new Paint(3);
        DemoView() { super(OverlayService.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight();
            p.setColor(Color.argb(220,0,230,118)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3f);
            c.drawRoundRect(w*.18f,h*.28f,w*.34f,h*.53f,8,8,p);
            c.drawRoundRect(w*.62f,h*.40f,w*.78f,h*.65f,8,8,p);
            p.setStyle(Paint.Style.FILL); p.setTextSize(dp(13)); p.setShadowLayer(3,1,1,Color.BLACK);
            c.drawText("ALVO DEMO 1 · 18 m",w*.12f,h*.26f,p); c.drawText("ALVO DEMO 2 · 32 m",w*.53f,h*.38f,p);
            p.clearShadowLayer(); p.setColor(Color.WHITE); p.setTextSize(dp(12));
            c.drawText("MARCADORES FICTÍCIOS",w*.05f,h*.10f,p);
        }
    }
}
