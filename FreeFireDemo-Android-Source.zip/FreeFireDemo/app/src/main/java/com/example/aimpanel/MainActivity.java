package com.example.aimpanel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(32), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(247,249,252));

        TextView title = new TextView(this);
        title.setText("Painel flutuante · Demo"); title.setTextSize(25);
        title.setTextColor(Color.rgb(20,35,55)); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(68)));

        TextView desc = new TextView(this);
        desc.setText("Ative o painel de demonstração e abra o Free Fire. Os marcadores são fictícios: o app não lê dados do jogo nem controla a mira.");
        desc.setTextSize(16); desc.setTextColor(Color.DKGRAY);
        desc.setPadding(0, dp(12), 0, dp(20)); root.addView(desc);

        Button start = new Button(this); start.setText("Ativar painel e abrir Free Fire");
        root.addView(start, new LinearLayout.LayoutParams(-1, dp(58)));
        Button panelOnly = new Button(this); panelOnly.setText("Mostrar painel sem abrir o jogo");
        root.addView(panelOnly, new LinearLayout.LayoutParams(-1, dp(54)));
        Button stop = new Button(this); stop.setText("Fechar painel flutuante");
        root.addView(stop, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView note = new TextView(this);
        note.setText("Na primeira utilização, autorize ‘Aparecer sobre outros apps’. Depois, toque novamente no botão desejado. Compatível com Free Fire ou Free Fire MAX instalados.");
        note.setTextSize(13); note.setTextColor(Color.GRAY); note.setPadding(0, dp(24), 0, 0); root.addView(note);
        setContentView(root);

        start.setOnClickListener(v -> activate(true));
        panelOnly.setOnClickListener(v -> activate(false));
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Painel fechado", Toast.LENGTH_SHORT).show();
        });
    }

    private void activate(boolean launchGame) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
            Toast.makeText(this, "Autorize a sobreposição e toque novamente no botão", Toast.LENGTH_LONG).show();
            return;
        }
        startService(new Intent(this, OverlayService.class));
        if (launchGame) {
            Intent game = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
            if (game == null) game = getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
            if (game != null) {
                game.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(game);
            } else {
                Toast.makeText(this, "Free Fire/Free Fire MAX não encontrado. Instale o jogo e tente novamente.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
